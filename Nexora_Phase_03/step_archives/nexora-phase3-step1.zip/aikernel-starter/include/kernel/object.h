#ifndef NEXORA_KERNEL_OBJECT_H
#define NEXORA_KERNEL_OBJECT_H

#include <kernel/types.h>

#define NX_OBJECT_REGISTRY_CAPACITY 1024u
#define NX_INVALID_HANDLE ((nx_handle_t)0)

typedef u64 nx_object_id_t;
typedef u64 nx_handle_t;

typedef enum {
    NX_OBJECT_INVALID = 0,
    NX_OBJECT_TENSOR,
    NX_OBJECT_WORK,
    NX_OBJECT_CAPABILITY,
    NX_OBJECT_MEMORY,
    NX_OBJECT_DOMAIN,
    NX_OBJECT_DEVICE,
    NX_OBJECT_TYPE_COUNT
} nx_object_type;

typedef enum {
    NX_OBJECT_NEW = 0,
    NX_OBJECT_LIVE,
    NX_OBJECT_QUIESCING,
    NX_OBJECT_DEAD
} nx_object_state;

typedef enum {
    NX_OBJECT_FLAG_NONE       = 0,
    NX_OBJECT_FLAG_KERNEL     = 1u << 0,
    NX_OBJECT_FLAG_PERSISTENT = 1u << 1
} nx_object_flags;

typedef struct nx_object {
    nx_object_id_t id;
    nx_handle_t handle;
    const char *name;
    nx_object_type type;
    nx_object_state state;
    u32 flags;
} nx_object;

typedef struct {
    u64 live;
    u64 high_watermark;
    u64 registrations;
    u64 retirements;
    u64 lookup_failures;
} nx_object_stats;

void nx_object_system_init(void);

bool nx_object_register(
    nx_object *object,
    nx_object_type type,
    const char *name,
    u32 flags
);

nx_object *nx_object_lookup(nx_handle_t handle, nx_object_type expected_type);

bool nx_object_transition(nx_object *object, nx_object_state next_state);
bool nx_object_retire(nx_object *object);

u64 nx_object_count(void);
const nx_object_stats *nx_object_get_stats(void);

const char *nx_object_type_name(nx_object_type type);
const char *nx_object_state_name(nx_object_state state);

#endif
