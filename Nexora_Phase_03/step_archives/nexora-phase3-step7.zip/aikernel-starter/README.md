# Nexora AIKernel Starter

A small **x86-64 experimental research kernel** intended as a foundation for exploring AI-native operating-system abstractions.

This is deliberately **not a Linux clone**. The initial design treats these as first-class concepts:

- tensors and their placement/lifetime metadata
- AI work units and dependency graphs
- heterogeneous compute targets (CPU/GPU/NPU)
- capability-based access control
- deadline/priority-aware scheduling
- data locality as an explicit concern

The current version is a bootable research skeleton. It does **not** yet run real GPU/NPU kernels.

## What already works

- Multiboot2 boot through GRUB
- transition from 32-bit GRUB entry to x86-64 long mode
- 1 GiB identity mapping using 2 MiB pages
- VGA text output
- COM1 serial output
- panic primitive
- tiny bump allocator
- generation-checked kernel object registry with owner IDs, strong refs, pins, and destructors
- tensor metadata with classes, shapes, byte strides, overflow-safe sizing, and layout tracking
- `NX_OBJECT_MEMORY` with page-aligned/page-rounded bootstrap backing
- tensor-to-memory strong-reference binding, offset views, bounds checking, pinning, and resident-byte accounting
- tensor lifetime engine with temporary/persistent/cached/shared/external policies and policy-aware backing reclamation
- producer/consumer tensor graph with one-producer/multi-consumer provenance
- scheduler data dependencies derived directly from tensor producer relationships
- final-consumer accounting and initial graph-triggered reclamation of temporary tensor backing
- AI-native work descriptors with work class, QoS, cost estimates, batch identity, and execution flags
- automatic logical tensor-I/O byte accounting for work nodes
- scheduler handling for explicit no-deadline semantics plus priority/deadline/QoS/duration ordering
- capability objects
- simple priority/dependency scheduler
- demonstration graph created during kernel boot

## Project layout

```text
aikernel-starter/
├── Makefile
├── linker.ld
├── grub.cfg
├── include/
│   ├── ai/
│   │   ├── capability.h
│   │   ├── device.h
│   │   ├── lifetime.h
│   │   ├── scheduler.h
│   │   ├── tensor.h
│   │   └── work.h
│   └── kernel/
│       ├── memory.h
│       ├── memory_object.h
│       ├── panic.h
│       ├── printk.h
│       └── types.h
├── src/
│   ├── ai/
│   ├── arch/x86_64/
│   ├── kernel/
│   └── mm/
├── docs/
│   ├── ARCHITECTURE.md
│   ├── DESIGN_PRINCIPLES.md
│   └── ROADMAP.md
└── scripts/
    ├── debug.sh
    └── run.sh
```

## Recommended build environment

A Debian/Ubuntu/Kali-like Linux system or WSL2.

Install:

```bash
sudo apt update
sudo apt install build-essential gcc binutils grub-pc-bin grub-common \
    xorriso qemu-system-x86 gdb
```

## Build

```bash
make
```

The build creates:

```text
build/kernel.elf
build/aikernel.iso
```

## Run in QEMU

```bash
make run
```

or:

```bash
./scripts/run.sh
```

Expected serial output includes:

```text
AIKernel x86_64 booted.
Early heap initialized.
Kernel object registry initialized.
Kernel object self-test passed.
AI runtime metadata initialized.
Memory ownership/refcount self-test passed.
Tensor metadata/backing/refcount self-test passed.
Tensor lifetime-engine self-test passed.
Producer/consumer graph self-test passed.
AI work-object redesign self-test passed.

[AIKernel demo]
tensor input ... class=input ... layout=contiguous ...
tensor weights ... class=weight ... layout=contiguous ...
scheduler selected node ...
...
AIKernel initialization complete.
```

## Debug

Terminal 1:

```bash
make debug
```

Terminal 2:

```bash
gdb build/kernel.elf
(gdb) target remote :1234
(gdb) break kmain
(gdb) continue
```

## Clean

```bash
make clean
```

## Research direction

The first serious experiments should compare an AI-native primitive with a conventional Linux implementation. Good early candidates:

1. tensor-aware allocator vs generic allocation
2. graph scheduler vs independent task queue
3. explicit tensor lifetime reclamation
4. topology-aware placement simulation
5. zero-copy shared tensor handles
6. capability-based agent resource access

Do **not** attempt GPU-driver development first. Prove one architectural advantage before expanding hardware support.

See `docs/ROADMAP.md`, `docs/PHASE3_STEP1_OBJECT_FOUNDATION.md`, `docs/PHASE3_STEP2_TENSOR_OBJECT.md`, `docs/PHASE3_STEP3_TENSOR_PHYSICAL_BACKING.md`, `docs/PHASE3_STEP4_OWNERSHIP_REFERENCE_COUNTING.md`, `docs/PHASE3_STEP5_TENSOR_LIFETIME_ENGINE.md`, `docs/PHASE3_STEP6_PRODUCER_CONSUMER_GRAPH.md`, and `docs/PHASE3_STEP7_AI_WORK_OBJECT_REDESIGN.md`.
