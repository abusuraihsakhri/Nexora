#include <ai/scheduler.h>

static u32 qos_rank(ai_work_qos qos) {
    switch (qos) {
        case AI_WORK_QOS_LATENCY: return 3;
        case AI_WORK_QOS_DEFAULT: return 2;
        case AI_WORK_QOS_THROUGHPUT: return 1;
        case AI_WORK_QOS_BACKGROUND: return 0;
        case AI_WORK_QOS_COUNT: break;
        default: break;
    }
    return 0;
}

/*
 * Step 7 keeps scheduling policy intentionally small, but makes it consume the
 * richer work metadata deterministically:
 *   1. higher explicit priority
 *   2. deadline-bearing work before no-deadline work; earlier deadline first
 *   3. submitter QoS intent
 *   4. shorter known duration as a final latency-friendly tie break
 *   5. lower object ID for stable reproducibility
 *
 * Device placement and transfer/locality cost are deliberately deferred to
 * Step 8 rather than being guessed here.
 */
static bool work_precedes(const ai_work_node *candidate, const ai_work_node *best) {
    if (best == NULL) {
        return true;
    }
    if (candidate->priority != best->priority) {
        return candidate->priority > best->priority;
    }

    const bool candidate_deadline = ai_work_has_deadline(candidate);
    const bool best_deadline = ai_work_has_deadline(best);
    if (candidate_deadline != best_deadline) {
        return candidate_deadline;
    }
    if (candidate_deadline && candidate->deadline_ns != best->deadline_ns) {
        return candidate->deadline_ns < best->deadline_ns;
    }

    const u32 candidate_qos = qos_rank(candidate->qos);
    const u32 best_qos = qos_rank(best->qos);
    if (candidate_qos != best_qos) {
        return candidate_qos > best_qos;
    }

    if (candidate->estimated_duration_ns != 0 && best->estimated_duration_ns != 0 &&
        candidate->estimated_duration_ns != best->estimated_duration_ns) {
        return candidate->estimated_duration_ns < best->estimated_duration_ns;
    }

    return candidate->object.id < best->object.id;
}

void ai_scheduler_init(ai_scheduler *scheduler, ai_work_graph *graph) {
    scheduler->graph = graph;
    scheduler->dispatch_count = 0;
    ai_work_refresh_states(graph);
}

ai_work_node *ai_scheduler_pick(ai_scheduler *scheduler) {
    if (scheduler == NULL || scheduler->graph == NULL) {
        return NULL;
    }

    ai_work_refresh_states(scheduler->graph);

    ai_work_node *best = NULL;

    for (u32 i = 0; i < scheduler->graph->node_count; ++i) {
        ai_work_node *candidate = scheduler->graph->nodes[i];

        if (candidate == NULL || candidate->state != AI_WORK_READY) {
            continue;
        }

        if (work_precedes(candidate, best)) {
            best = candidate;
        }
    }

    return best;
}

void ai_scheduler_mark_running(ai_scheduler *scheduler, ai_work_node *node) {
    if (scheduler == NULL || node == NULL) {
        return;
    }
    node->state = AI_WORK_RUNNING;
    ++scheduler->dispatch_count;
}

void ai_scheduler_mark_done(ai_scheduler *scheduler, ai_work_node *node) {
    (void)ai_scheduler_complete(scheduler, node);
}

ai_work_status ai_scheduler_complete(ai_scheduler *scheduler, ai_work_node *node) {
    if (scheduler == NULL || node == NULL) {
        return AI_WORK_ERR_INVALID_ARGUMENT;
    }
    return ai_work_complete(node);
}
