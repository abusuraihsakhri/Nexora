#ifndef AIKERNEL_AI_WORK_H
#define AIKERNEL_AI_WORK_H

#include <kernel/types.h>
#include <kernel/object.h>
#include <ai/tensor.h>
#include <ai/device.h>

#define AI_MAX_WORK_NODES 64
#define AI_MAX_DEPS        8
#define AI_MAX_INPUTS      8
#define AI_MAX_OUTPUTS     4

typedef enum {
    AI_OP_NOOP,
    AI_OP_MATMUL,
    AI_OP_ATTENTION,
    AI_OP_ACTIVATION,
    AI_OP_NORMALIZATION,
    AI_OP_EMBEDDING,
    AI_OP_TRANSFER,
    AI_OP_CUSTOM
} ai_op;

typedef enum {
    AI_WORK_PENDING,
    AI_WORK_READY,
    AI_WORK_RUNNING,
    AI_WORK_DONE,
    AI_WORK_FAILED
} ai_work_state;

typedef enum {
    AI_WORK_OK = 0,
    AI_WORK_ERR_INVALID_ARGUMENT,
    AI_WORK_ERR_GRAPH_FULL,
    AI_WORK_ERR_OBJECT_REGISTRY_FULL,
    AI_WORK_ERR_DEPENDENCIES_FULL,
    AI_WORK_ERR_INPUTS_FULL,
    AI_WORK_ERR_OUTPUTS_FULL,
    AI_WORK_ERR_CONSUMERS_FULL,
    AI_WORK_ERR_DUPLICATE_INPUT,
    AI_WORK_ERR_DUPLICATE_OUTPUT,
    AI_WORK_ERR_DUPLICATE_DEPENDENCY,
    AI_WORK_ERR_PRODUCER_EXISTS,
    AI_WORK_ERR_SELF_DEPENDENCY,
    AI_WORK_ERR_TENSOR_RETAIN_FAILED,
    AI_WORK_ERR_INVALID_STATE,
    AI_WORK_ERR_CONSUMER_NOT_FOUND,
    AI_WORK_ERR_CONSUMER_ALREADY_DONE
} ai_work_status;

typedef struct {
    u64 nodes_created;
    u64 producer_links;
    u64 consumer_links;
    u64 consumer_completions;
    u64 final_consumer_events;
    u64 automatic_reclaim_attempts;
    u64 automatic_reclaim_successes;
    u64 automatic_reclaim_deferred;
} ai_work_graph_stats;

struct ai_work_graph;

typedef struct ai_work_node {
    nx_object object;
    struct ai_work_graph *graph;
    ai_op op;
    ai_work_state state;

    u32 priority;
    u64 deadline_ns;
    u32 device_mask;

    /* Explicit control dependencies, represented by global work-object IDs. */
    u64 dependencies[AI_MAX_DEPS];
    u32 dependency_count;

    /* Work nodes own one strong tensor reference for every attached edge. */
    ai_tensor *inputs[AI_MAX_INPUTS];
    u32 input_count;

    ai_tensor *outputs[AI_MAX_OUTPUTS];
    u32 output_count;
} ai_work_node;

typedef struct ai_work_graph {
    ai_work_node *nodes[AI_MAX_WORK_NODES];
    u32 node_count;
    ai_work_graph_stats stats;
} ai_work_graph;

void ai_work_graph_init(ai_work_graph *graph);
void ai_work_graph_destroy(ai_work_graph *graph);
const ai_work_graph_stats *ai_work_graph_get_stats(const ai_work_graph *graph);

ai_work_node *ai_work_add(
    ai_work_graph *graph,
    const char *name,
    ai_op op,
    u32 priority,
    u64 deadline_ns,
    u32 device_mask
);

ai_work_status ai_work_try_add_dependency(ai_work_node *node, u64 dependency_id);
ai_work_status ai_work_try_add_input(ai_work_node *node, ai_tensor *tensor);
ai_work_status ai_work_try_add_output(ai_work_node *node, ai_tensor *tensor);

/* Panic-on-programmer-error compatibility wrappers. */
void ai_work_add_dependency(ai_work_node *node, u64 dependency_id);
void ai_work_add_input(ai_work_node *node, ai_tensor *tensor);
void ai_work_add_output(ai_work_node *node, ai_tensor *tensor);

bool ai_work_dependencies_done(const ai_work_graph *graph, const ai_work_node *node);
void ai_work_refresh_states(ai_work_graph *graph);

/*
 * Complete one work node and consume each of its input edges exactly once.
 * The final consumer event is connected to the Step 5 lifetime engine for
 * temporary tensors.
 */
ai_work_status ai_work_complete(ai_work_node *node);

nx_handle_t ai_tensor_producer_work(const ai_tensor *tensor);
u32 ai_tensor_consumer_count(const ai_tensor *tensor);
u32 ai_tensor_consumers_remaining(const ai_tensor *tensor);
bool ai_tensor_has_consumer(const ai_tensor *tensor, nx_handle_t work_handle);
bool ai_tensor_consumer_done(const ai_tensor *tensor, nx_handle_t work_handle);

const char *ai_work_state_name(ai_work_state state);
const char *ai_op_name(ai_op op);
const char *ai_work_status_name(ai_work_status status);

#endif
