# AIKernel v0 Architecture

## Current boot path

```text
GRUB / Multiboot2
        |
        v
32-bit protected-mode entry
        |
        v
minimal page tables
        |
        v
x86-64 long mode
        |
        v
kmain()
        |
        +--> console
        +--> early allocator
        +--> kernel object registry + ownership/refcounts
        +--> memory-object system
        +--> tensor registry + strong backing references
        +--> work graph
        +--> scheduler
        +--> capability prototype
```

## Proposed long-term architecture

```text
+------------------------------------------------------+
| Applications / agents / inference services          |
+--------------------------+---------------------------+
                           |
                           v
+------------------------------------------------------+
| AI Runtime ABI                                       |
| work submission | tensor handles | capabilities     |
+--------------------------+---------------------------+
                           |
                           v
+------------------------------------------------------+
| Work Graph Manager                                  |
| dependencies | deadlines | priorities | provenance  |
+--------------------------+---------------------------+
                           |
             +-------------+-------------+
             |                           |
             v                           v
+------------------------+    +------------------------+
| AI Scheduler           |    | Tensor Memory Manager  |
| CPU/GPU/NPU placement  |    | HBM/RAM/NVMe/remote   |
+-----------+------------+    +-----------+------------+
            |                             |
            +-------------+---------------+
                          |
                          v
+------------------------------------------------------+
| Capability + isolation layer                        |
+--------------------------+---------------------------+
                           |
                           v
+------------------------------------------------------+
| Device/resource model                               |
| CPU | GPU | NPU | NIC | NVMe | remote accelerator |
+------------------------------------------------------+
```

## Core kernel objects

### Tensor

A tensor is a typed multidimensional data object whose semantics are separate from
its storage. It now binds to `NX_OBJECT_MEMORY` through a generation-checked handle
and optional byte offset.

Implemented storage/lifetime fields include:

- backing memory handle
- backing offset/capacity
- page-granular resident backing through the bootstrap early-heap backend
- explicit object owner ID
- strong reference count
- pin count
- deterministic destructor callback
- tensor-owned strong references to backing memory
- lifetime class and residency state
- producer work handle
- consumer work handles, completion bitmask, and remaining-consumer count

Important future fields:

- arbitrary virtual mappings
- reuse distance hint
- NUMA/device locality
- compression/quantization state

### Work node

Represents schedulable computation.

Important fields:

- operation type
- dependencies
- input/output tensors
- deadline
- priority
- accelerator requirements
- estimated FLOPs
- estimated memory traffic
- placement cost

### Capability

Describes permission to operate on resources.

Future direction:

```text
capability = subject + object + rights + constraints
```

Example constraints:

- tensor range
- model identifier
- time limit
- accelerator quota
- network destination

## What v0 deliberately omits

- interrupts/IDT
- APIC
- SMP startup
- user mode
- syscalls
- filesystem
- networking
- PCI enumeration
- real GPU driver
- model runtime
- general physical page allocator / reclaimable tensor backing
- real device-memory allocator

Those should be added only after the architectural experiments are specified.


## Tensor lifetime policy

Phase 3 Step 5 makes lifetime a semantic property rather than an allocator side effect.
`TEMPORARY`, `PERSISTENT`, `CACHED`, `SHARED`, and `EXTERNAL` tensors use different
reclaim rules. The lifetime engine may detach backing while preserving the tensor object,
which allows graph-aware early reclamation and cache eviction without losing tensor identity.
Pins and shared strong references constrain reclamation. See
`PHASE3_STEP5_TENSOR_LIFETIME_ENGINE.md`.

## Producer/consumer dataflow

Phase 3 Step 6 makes dataflow provenance kernel-visible. Every tensor can have one
non-owning producer work handle and up to 32 unique non-owning consumer handles.
Work nodes hold the strong references to attached tensors, so the model does not
create reference-count cycles.

```text
Work producer
      |
      v
    Tensor
    /    \
   v      v
Work A  Work B
```

The scheduler treats a tensor producer as an implicit data dependency. A consumer
cannot become `READY` until the producer is `DONE`, even when no explicit work-ID
dependency was added.

Consumer completion decrements `consumers_remaining` exactly once. When the count
reaches zero, the graph emits a final-consumer event. For resident temporary
tensors, Step 6 connects that event to the Step 5 lifetime engine using
`AI_RECLAIM_FINAL_CONSUMER`. Tensor metadata and identity survive backing reclaim.
The broader deferred/pressure-aware reclamation mechanism remains a Step 9 task.
