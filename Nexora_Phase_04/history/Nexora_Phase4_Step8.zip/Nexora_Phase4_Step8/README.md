# Nexora / AIKernel — Phase 4 Step 8

This tree is the cumulative Nexora kernel prototype through **Phase 4 Step 8:
revocation and concurrency hardening**.

## Phase 4 progress

- Step 2 — work domains: implemented
- Step 3 — generation-protected per-domain handles: implemented
- Step 4 — capability-style handle rights: implemented
- Step 5 — cross-domain SHARE / TRANSFER: implemented
- Step 6 — shared physical tensor backing + zero-copy mapping: implemented
- Step 7 — handle/tensor/backing/mapping lifetime graph: implemented
- **Step 8 — revocation + SMP/concurrency hardening: implemented**
- Step 9 — adversarial security/correctness suite: next

## Step 8 model

```text
handle table (spinlock)
      │
      ├── LIVE token ── acquire() ──> stable object pin
      │                      │
      │                      └── atomic tensor/backing refcount
      │
      └── revoke() ──> REVOKED ──> reap/close ──> generation++

mapping table (spinlock)
      │
      ├── mapping ID
      └── acquire_view() ──> pinned tensor + backing snapshot
```

Tensor/backing final-reference transitions use atomic CAS loops, mapping counts
are atomic, domain lifecycle/accounting is atomic, and table mutations are
serialized with freestanding spinlocks.

A handle revoked after another CPU has already acquired an object pin stops all
new acquisitions immediately, but the pre-existing pin remains valid until the
holder releases it. This is the intended capability/lifetime separation.

## Important semantics

Step 8 implements **local token revocation**. It does not recursively revoke
previously delegated sibling/descendant handles in other domains. Transitive
capability-lineage revocation would require a separate revocation object/epoch
model and is intentionally not claimed here.

For concurrent kernel code, prefer:

```text
ai_handle_acquire() / ai_handle_release_object()
ai_mapping_acquire_view() / ai_mapping_release_view()
```

The older raw `resolve()` helpers are non-owning diagnostic/single-threaded
interfaces and should not be retained across concurrent close/unmap operations.

## New/changed Step 8 components

```text
include/kernel/spinlock.h
include/kernel/atomic.h
include/kernel/types.h
src/mm/bump.c

include/ai/handle.h
src/ai/handle.c
include/ai/mapping.h
src/ai/mapping.c
src/ai/tensor.c
src/ai/backing.c
src/ai/domain.c

src/kernel/kmain.c

tests/concurrency_host_test.c
docs/PHASE4_STEP8.md
```

## Build and test

```bash
make build/kernel.elf
make test-host
make test-host-sanitize
make test-host-tsan
```

`test-host-tsan` executes the Step 8 pthread stress/race suite under
ThreadSanitizer.

See `VALIDATION.txt` for the exact validation performed for this package.

## Remaining platform boundaries

- no per-domain hardware page tables/user mode yet,
- no reusable page-frame/kernel-heap allocator yet,
- no actual kernel SMP startup/APIC scheduler yet,
- no managed lifetime hooks for WORK/GENERIC handle object types yet,
- spinlocks are not yet IRQ-save/preemption-aware.

## Next

**Phase 4 Step 9 — adversarial security and correctness testing**: systematic
invalid-token fuzzing, rights-matrix tests, revocation/close/unmap race matrices,
refcount overflow/underflow checks, table-exhaustion tests, and longer stress
runs before the Step 10 benchmark/integration gate.
