# Nexora / AIKernel — Phase 4 Step 7

This tree is the cumulative Nexora kernel prototype through **Phase 4 Step 7:
reference counting and lifetime management**.

## Phase 4 progress

- Step 2 — work domains: implemented
- Step 3 — generation-protected per-domain handles: implemented
- Step 4 — capability-style handle rights: implemented
- Step 5 — cross-domain SHARE / TRANSFER: implemented
- Step 6 — shared physical tensor backing + zero-copy mapping: implemented
- **Step 7 — handle/tensor/backing/mapping lifetime graph: implemented**
- Step 8 — revocation + concurrency safety: next

## Step 7 ownership graph

```text
handle(s) -----------\
creator pointer ------+--> ai_tensor
mapping(s) -----------/      refcount
                           |
                           | retained backing ref
                           v
creator backing ------\
                       +--> ai_tensor_backing
mapping(s) ------------/      refcount + mapping_count
```

Managed tensors and backings now have explicit `LIVE -> RETIRED` lifetime
states. Handle installation retains managed objects, handle close releases them,
and every mapping owns independent tensor/backing references. Closing all
handles therefore does not invalidate an established mapping.

The final mapping release can retire the tensor; tensor retirement releases its
backing reference; the backing retires when its final reference disappears.
Retired objects cannot be resurrected.

## Important allocator boundary

The current kernel still uses the early bump allocator, which has no `free()`.
Step 7 therefore provides correct **logical reclamation** and registry removal,
but not physical page recycling. Physical storage reuse must wait for the
page-frame allocator/kernel heap milestone. This limitation is explicit in the
design and validation notes.

## New/changed Step 7 components

```text
include/ai/tensor.h
src/ai/tensor.c
include/ai/backing.h
src/ai/backing.c
src/ai/handle.c
src/ai/mapping.c

tests/lifetime_host_test.c
docs/PHASE4_STEP7.md
```

## Build and test

Build the kernel ELF:

```bash
make build/kernel.elf
```

Run the full host test suite:

```bash
make test-host
```

Run lifetime/mapping tests under AddressSanitizer + UBSan:

```bash
make test-host-sanitize
```

See `VALIDATION.txt` for the exact validation performed for this package.

## Next

**Phase 4 Step 8 — revocation and concurrency safety** will introduce the
synchronization contract for handle/mapping mutation, final-reference races,
revocation, and SMP-safe stale-reference handling.
