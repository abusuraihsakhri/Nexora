#include <ai/handle.h>
#include <ai/backing.h>
#include <ai/domain.h>
#include <ai/tensor.h>
#include <kernel/panic.h>

#define AI_HANDLE_SLOT_MASK        0xffull
#define AI_HANDLE_GENERATION_MASK  0xffffffull
#define AI_HANDLE_DOMAIN_MASK      0xffffffffull
#define AI_HANDLE_GENERATION_SHIFT 8u
#define AI_HANDLE_DOMAIN_SHIFT     32u

_Static_assert(AI_DOMAIN_MAX_HANDLES <= 255u,
               "handle slot encoding supports at most 255 entries");

static u32 next_generation(u32 current) {
    u32 next = (current + 1u) & (u32)AI_HANDLE_GENERATION_MASK;
    if (next == 0) {
        next = 1;
    }
    return next;
}

static ai_handle_t encode_handle(
    u32 domain_tag,
    u32 generation,
    u32 slot_index
) {
    u64 slot_token = (u64)(slot_index + 1u);
    u64 generation_bits =
        ((u64)generation & AI_HANDLE_GENERATION_MASK)
        << AI_HANDLE_GENERATION_SHIFT;
    u64 domain_bits =
        ((u64)domain_tag & AI_HANDLE_DOMAIN_MASK)
        << AI_HANDLE_DOMAIN_SHIFT;

    return domain_bits | generation_bits | slot_token;
}

static bool decode_slot(ai_handle_t handle, u32 *slot_index) {
    u32 slot_token = (u32)(handle & AI_HANDLE_SLOT_MASK);
    if (slot_token == 0 || slot_token > AI_DOMAIN_MAX_HANDLES) {
        return false;
    }

    if (slot_index) {
        *slot_index = slot_token - 1u;
    }
    return true;
}

static bool domain_accepts_existing_handles(const ai_domain *domain) {
    if (!domain) {
        return false;
    }
    return domain->state == AI_DOMAIN_ACTIVE ||
           domain->state == AI_DOMAIN_QUIESCING;
}

static bool rights_are_subset(
    ai_handle_rights_t candidate,
    ai_handle_rights_t current
) {
    return (candidate & current) == candidate;
}

static bool object_reference_acquire(
    void *object,
    ai_handle_object_type type
) {
    if (!object) {
        return false;
    }

    switch (type) {
        case AI_HANDLE_OBJECT_TENSOR:
            return ai_tensor_get((ai_tensor *)object);
        case AI_HANDLE_OBJECT_BACKING:
            return ai_backing_get((ai_tensor_backing *)object);
        case AI_HANDLE_OBJECT_WORK:
        case AI_HANDLE_OBJECT_GENERIC:
            /* Work/generic objects gain explicit lifetime hooks later. */
            return true;
        default:
            return false;
    }
}

static bool object_reference_release(
    void *object,
    ai_handle_object_type type
) {
    if (!object) {
        return false;
    }

    switch (type) {
        case AI_HANDLE_OBJECT_TENSOR:
            return ai_tensor_put((ai_tensor *)object);
        case AI_HANDLE_OBJECT_BACKING:
            return ai_backing_put((ai_tensor_backing *)object);
        case AI_HANDLE_OBJECT_WORK:
        case AI_HANDLE_OBJECT_GENERIC:
            return true;
        default:
            return false;
    }
}

static bool rights_compatible_with_object(
    void *object,
    ai_handle_object_type type,
    ai_handle_rights_t rights
) {
    if (!object || !ai_handle_rights_valid(rights)) {
        return false;
    }

    /*
     * Object-level immutability is stronger than handle-level authority.
     * A read-only tensor must never receive a WRITE-capable handle.
     */
    if (type == AI_HANDLE_OBJECT_TENSOR) {
        const ai_tensor *tensor = (const ai_tensor *)object;
        if ((tensor->flags & AI_TENSOR_READONLY) != 0 &&
            (rights & AI_HANDLE_RIGHT_WRITE) != 0) {
            return false;
        }
    }

    return true;
}

static const ai_handle_entry *lookup_entry_const(
    const ai_domain *domain,
    ai_handle_t handle
) {
    if (!domain_accepts_existing_handles(domain) ||
        handle == AI_HANDLE_INVALID) {
        return NULL;
    }

    if (ai_handle_domain_tag(handle) != (u32)domain->id) {
        return NULL;
    }

    u32 slot_index = 0;
    if (!decode_slot(handle, &slot_index)) {
        return NULL;
    }

    const ai_handle_entry *entry = &domain->handles.entries[slot_index];
    if (!entry->occupied || !entry->object) {
        return NULL;
    }

    if (entry->generation != ai_handle_generation(handle)) {
        return NULL;
    }

    return entry;
}

static ai_handle_entry *lookup_entry(
    ai_domain *domain,
    ai_handle_t handle
) {
    return (ai_handle_entry *)lookup_entry_const(domain, handle);
}

void ai_handle_table_init(ai_handle_table *table) {
    if (!table) {
        return;
    }

    table->live_count = 0;
    for (u32 i = 0; i < AI_DOMAIN_MAX_HANDLES; ++i) {
        table->entries[i].object = NULL;
        table->entries[i].generation = 1;
        table->entries[i].type = AI_HANDLE_OBJECT_NONE;
        table->entries[i].rights = 0;
        table->entries[i].occupied = false;
    }
}

bool ai_handle_rights_valid(ai_handle_rights_t rights) {
    if (rights == 0) {
        return false;
    }
    return (rights & ~AI_HANDLE_RIGHT_ALL) == 0;
}

ai_handle_t ai_handle_install(
    ai_domain *domain,
    void *object,
    ai_handle_object_type type,
    ai_handle_rights_t rights
) {
    if (!domain || !object || domain->state != AI_DOMAIN_ACTIVE) {
        return AI_HANDLE_INVALID;
    }

    if (type == AI_HANDLE_OBJECT_NONE || type == AI_HANDLE_OBJECT_ANY) {
        return AI_HANDLE_INVALID;
    }

    if (!rights_compatible_with_object(object, type, rights)) {
        return AI_HANDLE_INVALID;
    }

    if (domain->id == 0 || domain->id > AI_DOMAIN_ID_MAX) {
        return AI_HANDLE_INVALID;
    }

    for (u32 i = 0; i < AI_DOMAIN_MAX_HANDLES; ++i) {
        ai_handle_entry *entry = &domain->handles.entries[i];
        if (entry->occupied) {
            continue;
        }

        if (!object_reference_acquire(object, type)) {
            return AI_HANDLE_INVALID;
        }

        entry->object = object;
        entry->type = type;
        entry->rights = rights;
        entry->occupied = true;
        domain->handles.live_count++;

        return encode_handle(
            (u32)domain->id,
            entry->generation,
            i
        );
    }

    return AI_HANDLE_INVALID;
}

void *ai_handle_resolve(
    const ai_domain *domain,
    ai_handle_t handle,
    ai_handle_object_type expected_type,
    ai_handle_rights_t required_rights
) {
    if (required_rights != 0 &&
        !ai_handle_rights_valid(required_rights)) {
        return NULL;
    }

    const ai_handle_entry *entry = lookup_entry_const(domain, handle);
    if (!entry) {
        return NULL;
    }

    if (expected_type != AI_HANDLE_OBJECT_ANY &&
        entry->type != expected_type) {
        return NULL;
    }

    if (!rights_are_subset(required_rights, entry->rights)) {
        return NULL;
    }

    return entry->object;
}

bool ai_handle_is_valid(
    const ai_domain *domain,
    ai_handle_t handle,
    ai_handle_object_type expected_type,
    ai_handle_rights_t required_rights
) {
    return ai_handle_resolve(
        domain,
        handle,
        expected_type,
        required_rights
    ) != NULL;
}

bool ai_handle_has_rights(
    const ai_domain *domain,
    ai_handle_t handle,
    ai_handle_rights_t required_rights
) {
    if (!ai_handle_rights_valid(required_rights)) {
        return false;
    }

    const ai_handle_entry *entry = lookup_entry_const(domain, handle);
    if (!entry) {
        return false;
    }

    return rights_are_subset(required_rights, entry->rights);
}

ai_handle_rights_t ai_handle_get_rights(
    const ai_domain *domain,
    ai_handle_t handle
) {
    const ai_handle_entry *entry = lookup_entry_const(domain, handle);
    if (!entry) {
        return 0;
    }
    return entry->rights;
}

bool ai_handle_restrict_rights(
    ai_domain *domain,
    ai_handle_t handle,
    ai_handle_rights_t new_rights
) {
    if (!ai_handle_rights_valid(new_rights)) {
        return false;
    }

    ai_handle_entry *entry = lookup_entry(domain, handle);
    if (!entry) {
        return false;
    }

    if (!rights_are_subset(new_rights, entry->rights)) {
        return false;
    }

    entry->rights = new_rights;
    return true;
}

static bool domains_allow_delegation(
    const ai_domain *source_domain,
    const ai_domain *target_domain
) {
    if (!source_domain || !target_domain || source_domain == target_domain) {
        return false;
    }

    /*
     * Delegation mints authority in the target namespace, so neither endpoint
     * may be quiescing. Existing handles remain usable during quiescence only
     * for draining/cleanup.
     */
    return source_domain->state == AI_DOMAIN_ACTIVE &&
           target_domain->state == AI_DOMAIN_ACTIVE;
}

static ai_handle_t delegate_handle(
    ai_domain *source_domain,
    ai_handle_t source_handle,
    ai_domain *target_domain,
    ai_handle_rights_t requested_rights,
    ai_handle_rights_t delegation_right
) {
    if (!domains_allow_delegation(source_domain, target_domain) ||
        !ai_handle_rights_valid(requested_rights)) {
        return AI_HANDLE_INVALID;
    }

    const ai_handle_entry *source_entry = lookup_entry_const(
        source_domain,
        source_handle
    );
    if (!source_entry) {
        return AI_HANDLE_INVALID;
    }

    if (!rights_are_subset(delegation_right, source_entry->rights) ||
        !rights_are_subset(requested_rights, source_entry->rights)) {
        return AI_HANDLE_INVALID;
    }

    return ai_handle_install(
        target_domain,
        source_entry->object,
        source_entry->type,
        requested_rights
    );
}

ai_handle_t ai_handle_share(
    ai_domain *source_domain,
    ai_handle_t source_handle,
    ai_domain *target_domain,
    ai_handle_rights_t requested_rights
) {
    return delegate_handle(
        source_domain,
        source_handle,
        target_domain,
        requested_rights,
        AI_HANDLE_RIGHT_SHARE
    );
}

ai_handle_t ai_handle_transfer(
    ai_domain *source_domain,
    ai_handle_t source_handle,
    ai_domain *target_domain,
    ai_handle_rights_t requested_rights
) {
    ai_handle_t target_handle = delegate_handle(
        source_domain,
        source_handle,
        target_domain,
        requested_rights,
        AI_HANDLE_RIGHT_TRANSFER
    );
    if (target_handle == AI_HANDLE_INVALID) {
        return AI_HANDLE_INVALID;
    }

    /*
     * Commit order matters: destination first, source second. That preserves a
     * valid object reference throughout the move. In the current single-core
     * prototype, close should succeed after the validation above. The rollback
     * path is kept explicit so Step 8 can place this sequence under locking.
     */
    if (!ai_handle_close(source_domain, source_handle)) {
        (void)ai_handle_close(target_domain, target_handle);
        return AI_HANDLE_INVALID;
    }

    return target_handle;
}

bool ai_handle_close(ai_domain *domain, ai_handle_t handle) {
    if (!domain_accepts_existing_handles(domain) ||
        handle == AI_HANDLE_INVALID) {
        return false;
    }

    ai_handle_entry *entry = lookup_entry(domain, handle);
    if (!entry || domain->handles.live_count == 0) {
        return false;
    }

    void *object = entry->object;
    ai_handle_object_type type = entry->type;

    /* Invalidate the namespace entry before releasing the object reference. */
    entry->object = NULL;
    entry->type = AI_HANDLE_OBJECT_NONE;
    entry->rights = 0;
    entry->occupied = false;
    entry->generation = next_generation(entry->generation);
    domain->handles.live_count--;

    if (!object_reference_release(object, type)) {
        panic("handle close failed to release object reference");
    }
    return true;
}

u32 ai_handle_live_count(const ai_domain *domain) {
    if (!domain) {
        return 0;
    }
    return domain->handles.live_count;
}

u32 ai_handle_domain_tag(ai_handle_t handle) {
    return (u32)((handle >> AI_HANDLE_DOMAIN_SHIFT) & AI_HANDLE_DOMAIN_MASK);
}

u32 ai_handle_generation(ai_handle_t handle) {
    return (u32)(
        (handle >> AI_HANDLE_GENERATION_SHIFT) &
        AI_HANDLE_GENERATION_MASK
    );
}

u32 ai_handle_slot(ai_handle_t handle) {
    u32 slot_index = 0;
    if (!decode_slot(handle, &slot_index)) {
        return 0xffffffffu;
    }
    return slot_index;
}

const char *ai_handle_object_type_name(ai_handle_object_type type) {
    switch (type) {
        case AI_HANDLE_OBJECT_NONE:    return "NONE";
        case AI_HANDLE_OBJECT_TENSOR:  return "TENSOR";
        case AI_HANDLE_OBJECT_BACKING: return "BACKING";
        case AI_HANDLE_OBJECT_WORK:    return "WORK";
        case AI_HANDLE_OBJECT_GENERIC: return "GENERIC";
        case AI_HANDLE_OBJECT_ANY:     return "ANY";
        default:                       return "UNKNOWN";
    }
}
