#include <ai/backing.h>
#include <kernel/memory.h>
#include <kernel/panic.h>

static ai_tensor_backing *registry[AI_MAX_BACKINGS];
static u64 backing_count = 0;
static u64 next_backing_id = 1;

static u64 align_up_page(u64 value) {
    if (value == 0) {
        return 0;
    }
    return (value + AI_BACKING_PAGE_SIZE - 1ull) &
           ~(AI_BACKING_PAGE_SIZE - 1ull);
}

static void retire_backing(ai_tensor_backing *backing) {
    if (!backing || backing->lifetime_state != AI_BACKING_LIVE) {
        return;
    }

    /* Every mapping owns a reference. Zero references with a live mapping is
     * therefore a lifetime invariant violation rather than a valid teardown. */
    if (backing->mapping_count != 0) {
        panic("retiring tensor backing with live mappings");
    }

    for (u32 i = 0; i < AI_MAX_BACKINGS; ++i) {
        if (registry[i] == backing) {
            registry[i] = NULL;
            if (backing_count == 0) {
                panic("tensor backing registry underflow");
            }
            backing_count--;
            break;
        }
    }

    backing->lifetime_state = AI_BACKING_RETIRED;

    /*
     * The Phase 1 early bump allocator cannot physically free or coalesce the
     * storage yet. Retiring removes the object from all Nexora registries and
     * makes future get/map/address operations fail. Physical page recycling is
     * deferred until the page-frame/kernel-heap allocator replaces kalloc().
     */
}

void ai_backing_system_init(void) {
    for (u32 i = 0; i < AI_MAX_BACKINGS; ++i) {
        registry[i] = NULL;
    }
    backing_count = 0;
    next_backing_id = 1;
}

ai_tensor_backing *ai_backing_create_ram(u64 size_bytes, u32 flags) {
    if (size_bytes == 0 || backing_count >= AI_MAX_BACKINGS) {
        return NULL;
    }

    u64 allocation_bytes = align_up_page(size_bytes);
    if (allocation_bytes < size_bytes) {
        return NULL;
    }

    ai_tensor_backing *backing =
        (ai_tensor_backing *)kalloc(sizeof(ai_tensor_backing), 16);
    void *storage = kalloc((usize)allocation_bytes, (usize)AI_BACKING_PAGE_SIZE);

    backing->id = next_backing_id++;
    backing->kind = AI_BACKING_RAM;
    backing->size_bytes = size_bytes;
    backing->allocation_bytes = allocation_bytes;
    backing->page_count = allocation_bytes / AI_BACKING_PAGE_SIZE;
    backing->kernel_base = storage;
    backing->physical_base = (u64)(usize)storage;
    backing->refcount = 1; /* creator reference */
    backing->mapping_count = 0;
    backing->lifetime_state = AI_BACKING_LIVE;
    backing->flags = flags;

    if ((flags & AI_BACKING_ZEROED) != 0) {
        u8 *bytes = (u8 *)storage;
        for (u64 i = 0; i < allocation_bytes; ++i) {
            bytes[i] = 0;
        }
    }

    for (u32 i = 0; i < AI_MAX_BACKINGS; ++i) {
        if (registry[i] == NULL) {
            registry[i] = backing;
            backing_count++;
            return backing;
        }
    }

    panic("tensor backing registry invariant violated");
    return NULL;
}

bool ai_backing_get(ai_tensor_backing *backing) {
    if (!backing || backing->lifetime_state != AI_BACKING_LIVE ||
        backing->refcount == 0 || backing->refcount == ~0ull) {
        return false;
    }

    backing->refcount++;
    return true;
}

bool ai_backing_put(ai_tensor_backing *backing) {
    if (!backing || backing->lifetime_state != AI_BACKING_LIVE ||
        backing->refcount == 0) {
        return false;
    }

    backing->refcount--;
    if (backing->refcount == 0) {
        retire_backing(backing);
    }
    return true;
}

bool ai_backing_is_live(const ai_tensor_backing *backing) {
    return backing && backing->lifetime_state == AI_BACKING_LIVE &&
           backing->refcount != 0;
}

u64 ai_backing_refcount(const ai_tensor_backing *backing) {
    return backing ? backing->refcount : 0;
}

bool ai_backing_mapping_acquire(ai_tensor_backing *backing) {
    if (!backing || backing->mapping_count == ~0ull) {
        return false;
    }
    if (!ai_backing_get(backing)) {
        return false;
    }

    backing->mapping_count++;
    return true;
}

bool ai_backing_mapping_release(ai_tensor_backing *backing) {
    if (!backing || backing->lifetime_state != AI_BACKING_LIVE ||
        backing->mapping_count == 0) {
        return false;
    }

    backing->mapping_count--;
    if (!ai_backing_put(backing)) {
        panic("tensor backing mapping release lost reference");
    }
    return true;
}

u64 ai_backing_count(void) {
    return backing_count;
}

u64 ai_backing_physical_at(const ai_tensor_backing *backing, u64 offset) {
    if (!ai_backing_is_live(backing) || offset >= backing->allocation_bytes) {
        return 0;
    }
    return backing->physical_base + offset;
}

void *ai_backing_kernel_at(const ai_tensor_backing *backing, u64 offset) {
    if (!ai_backing_is_live(backing) || !backing->kernel_base ||
        offset >= backing->allocation_bytes) {
        return NULL;
    }
    return (void *)((u8 *)backing->kernel_base + offset);
}

const char *ai_backing_kind_name(ai_backing_kind kind) {
    switch (kind) {
        case AI_BACKING_RAM:    return "RAM";
        case AI_BACKING_DEVICE: return "DEVICE";
        case AI_BACKING_PINNED: return "PINNED";
        case AI_BACKING_REMOTE: return "REMOTE";
        default:                return "UNKNOWN";
    }
}

const char *ai_backing_lifetime_state_name(ai_backing_lifetime_state state) {
    switch (state) {
        case AI_BACKING_LIVE:    return "LIVE";
        case AI_BACKING_RETIRED: return "RETIRED";
        default:                 return "UNKNOWN";
    }
}
