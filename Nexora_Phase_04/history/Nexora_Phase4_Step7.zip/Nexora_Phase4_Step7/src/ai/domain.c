#include <ai/domain.h>
#include <kernel/memory.h>
#include <kernel/panic.h>

static ai_domain *registry[AI_MAX_DOMAINS];
static u64 domain_count = 0;
static ai_domain_id_t next_domain_id = 1;

static bool domain_is_live(const ai_domain *domain) {
    return domain && domain->state != AI_DOMAIN_DEAD;
}

static bool limit_u64_allows(u64 limit, u64 used, u64 add) {
    if (limit == 0) {
        return true;
    }
    if (used > limit) {
        return false;
    }
    return add <= (limit - used);
}

static bool limit_u32_allows(u32 limit, u32 used) {
    if (limit == 0) {
        return true;
    }
    return used < limit;
}

void ai_domain_system_init(void) {
    for (u32 i = 0; i < AI_MAX_DOMAINS; ++i) {
        registry[i] = NULL;
    }
    domain_count = 0;
    next_domain_id = 1;
}

ai_domain *ai_domain_create(
    const char *name,
    u32 flags,
    ai_domain_limits limits
) {
    if (domain_count >= AI_MAX_DOMAINS) {
        panic("domain registry full");
    }
    if (next_domain_id == 0 || next_domain_id > AI_DOMAIN_ID_MAX) {
        panic("domain id space exhausted");
    }

    ai_domain *domain = (ai_domain *)kalloc(sizeof(ai_domain), 16);
    domain->id = next_domain_id++;
    domain->name = name;
    domain->state = AI_DOMAIN_NEW;
    domain->flags = flags;
    domain->limits = limits;
    domain->memory_used_bytes = 0;
    domain->tensor_count = 0;
    domain->work_node_count = 0;
    ai_handle_table_init(&domain->handles);
    ai_mapping_table_init(&domain->mappings, domain->id);

    for (u32 i = 0; i < AI_MAX_DOMAINS; ++i) {
        if (registry[i] == NULL) {
            registry[i] = domain;
            domain_count++;
            return domain;
        }
    }

    panic("domain registry invariant violated");
    return NULL;
}

ai_domain *ai_domain_lookup(ai_domain_id_t id) {
    if (id == 0) {
        return NULL;
    }

    for (u32 i = 0; i < AI_MAX_DOMAINS; ++i) {
        ai_domain *domain = registry[i];
        if (domain && domain->id == id && domain->state != AI_DOMAIN_DEAD) {
            return domain;
        }
    }
    return NULL;
}

bool ai_domain_activate(ai_domain *domain) {
    if (!domain || domain->state != AI_DOMAIN_NEW) {
        return false;
    }
    domain->state = AI_DOMAIN_ACTIVE;
    return true;
}

bool ai_domain_begin_quiesce(ai_domain *domain) {
    if (!domain || domain->state != AI_DOMAIN_ACTIVE) {
        return false;
    }
    domain->state = AI_DOMAIN_QUIESCING;
    return true;
}

bool ai_domain_destroy(ai_domain *domain) {
    if (!domain || domain->state == AI_DOMAIN_DEAD) {
        return false;
    }

    /*
     * A domain cannot disappear while resources or externally visible
     * object handles are still attributed to it.
     */
    if (domain->memory_used_bytes != 0 ||
        domain->tensor_count != 0 ||
        domain->work_node_count != 0 ||
        ai_handle_live_count(domain) != 0 ||
        ai_mapping_live_count(domain) != 0) {
        return false;
    }

    if (domain->state == AI_DOMAIN_ACTIVE) {
        return false;
    }

    for (u32 i = 0; i < AI_MAX_DOMAINS; ++i) {
        if (registry[i] == domain) {
            registry[i] = NULL;
            domain->state = AI_DOMAIN_DEAD;
            domain_count--;
            /*
             * The early bump allocator has no free operation. The object is
             * therefore retired logically. A later allocator will reclaim it.
             */
            return true;
        }
    }

    return false;
}

bool ai_domain_charge_memory(ai_domain *domain, u64 bytes) {
    if (!domain_is_live(domain) || domain->state != AI_DOMAIN_ACTIVE) {
        return false;
    }
    if (!limit_u64_allows(
            domain->limits.memory_bytes,
            domain->memory_used_bytes,
            bytes)) {
        return false;
    }

    domain->memory_used_bytes += bytes;
    return true;
}

void ai_domain_uncharge_memory(ai_domain *domain, u64 bytes) {
    if (!domain_is_live(domain)) {
        return;
    }
    if (bytes > domain->memory_used_bytes) {
        panic("domain memory accounting underflow");
    }
    domain->memory_used_bytes -= bytes;
}

bool ai_domain_reserve_tensor(ai_domain *domain) {
    if (!domain_is_live(domain) || domain->state != AI_DOMAIN_ACTIVE) {
        return false;
    }
    if (!limit_u32_allows(domain->limits.max_tensors, domain->tensor_count)) {
        return false;
    }
    domain->tensor_count++;
    return true;
}

void ai_domain_release_tensor(ai_domain *domain) {
    if (!domain_is_live(domain)) {
        return;
    }
    if (domain->tensor_count == 0) {
        panic("domain tensor accounting underflow");
    }
    domain->tensor_count--;
}

bool ai_domain_reserve_work_node(ai_domain *domain) {
    if (!domain_is_live(domain) || domain->state != AI_DOMAIN_ACTIVE) {
        return false;
    }
    if (!limit_u32_allows(
            domain->limits.max_work_nodes,
            domain->work_node_count)) {
        return false;
    }
    domain->work_node_count++;
    return true;
}

void ai_domain_release_work_node(ai_domain *domain) {
    if (!domain_is_live(domain)) {
        return;
    }
    if (domain->work_node_count == 0) {
        panic("domain work accounting underflow");
    }
    domain->work_node_count--;
}

u64 ai_domain_count(void) {
    return domain_count;
}

const char *ai_domain_state_name(ai_domain_state state) {
    switch (state) {
        case AI_DOMAIN_NEW:       return "NEW";
        case AI_DOMAIN_ACTIVE:    return "ACTIVE";
        case AI_DOMAIN_QUIESCING: return "QUIESCING";
        case AI_DOMAIN_DEAD:      return "DEAD";
        default:                  return "UNKNOWN";
    }
}
