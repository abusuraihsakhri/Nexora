# Nexora / AIKernel — Phase 4 Step 9

This tree is the cumulative Nexora kernel prototype through **Phase 4 Step 9:
adversarial security and correctness validation**.

## Phase 4 progress

- Step 2 — work domains: implemented
- Step 3 — generation-protected per-domain handles: implemented
- Step 4 — capability-style handle rights: implemented
- Step 5 — cross-domain SHARE / TRANSFER: implemented
- Step 6 — shared physical tensor backing + zero-copy mapping: implemented
- Step 7 — handle/tensor/backing/mapping lifetime graph: implemented
- Step 8 — revocation + SMP/concurrency hardening: implemented
- **Step 9 — adversarial/fuzz/race/stress validation: implemented**
- Step 10 — zero-copy benchmark + Phase 4 integration gate: next

## Step 9 coverage

```text
handles
  ├── full rights matrix
  ├── 100,000 forged-token fuzz cases
  ├── table exhaustion
  ├── stale-token reuse
  └── terminal generation boundary

mappings
  ├── invalid ranges/protection
  ├── 50,000 forged-ID fuzz cases
  ├── table exhaustion
  ├── stale-ID reuse
  ├── virtual-window exhaustion
  └── domain-window arithmetic overflow

concurrency
  ├── close vs revoke
  ├── close vs acquire
  ├── unmap vs view
  ├── multi-unmap
  ├── randomized handle churn
  ├── randomized map/view/unmap churn
  └── randomized cross-domain SHARE churn
```

## Hardening added by Step 9

Two production-path changes were made because of the adversarial review:

1. 24-bit handle/mapping generations **never wrap**. A slot is permanently
   exhausted at the terminal generation, preventing stale-token ABA revival.
2. Per-domain mapping virtual-window arithmetic is overflow checked before a
   window is constructed.

The backing API also exposes `ai_backing_mapping_count()` as a read-only atomic
invariant/diagnostic accessor.

## Build and validation

```bash
make build/kernel.elf
make test-host
make test-host-sanitize
make test-host-tsan
make test-host-step9-sanitize
make test-host-step9-tsan
make test-host-step9-stress
```

See `VALIDATION.txt` and `docs/PHASE4_STEP9.md` for the exact coverage and
remaining architectural boundaries.

## Important concurrency rule

Concurrent users must retain stable references with:

```text
ai_handle_acquire() / ai_handle_release_object()
ai_mapping_acquire_view() / ai_mapping_release_view()
```

Raw `resolve()`/address helpers remain diagnostic/non-owning interfaces.

Shared tensor payload bytes are genuinely shared. Concurrent modification of
the same payload region therefore requires synchronization from the execution
or graph layer; the handle/mapping subsystem protects metadata and lifetime, not
arbitrary application data races.

## Next

**Phase 4 Step 10 — zero-copy benchmark and integration gate**: compare memcpy
IPC against shared-handle mapping for latency, bytes copied, peak memory,
metadata overhead, and scheduler integration.
