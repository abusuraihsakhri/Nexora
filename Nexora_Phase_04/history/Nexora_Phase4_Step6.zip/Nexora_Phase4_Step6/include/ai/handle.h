#ifndef AIKERNEL_AI_HANDLE_H
#define AIKERNEL_AI_HANDLE_H

#include <kernel/types.h>

/*
 * Phase 4 Step 5: domain-scoped opaque handles, rights, and delegation.
 *
 * Handle token layout is unchanged from Step 3:
 *
 *   63                              32 31             8 7        0
 *  +----------------------------------+----------------+----------+
 *  |          domain tag (32)         | generation(24) | slot(8)  |
 *  +----------------------------------+----------------+----------+
 *
 * Rights are deliberately NOT encoded in the numeric token. They live in
 * the protected per-domain handle-table entry, so authority can be reduced
 * without minting a new token and cannot be forged by editing handle bits.
 */

typedef u64 ai_handle_t;
typedef u32 ai_handle_rights_t;

#define AI_HANDLE_INVALID ((ai_handle_t)0)
#define AI_DOMAIN_MAX_HANDLES 64u

typedef enum {
    AI_HANDLE_OBJECT_NONE = 0,
    AI_HANDLE_OBJECT_TENSOR,
    AI_HANDLE_OBJECT_BACKING,
    AI_HANDLE_OBJECT_WORK,
    AI_HANDLE_OBJECT_GENERIC,
    AI_HANDLE_OBJECT_ANY = 0xff
} ai_handle_object_type;

enum {
    AI_HANDLE_RIGHT_READ     = 1u << 0,
    AI_HANDLE_RIGHT_WRITE    = 1u << 1,
    AI_HANDLE_RIGHT_MAP      = 1u << 2,
    AI_HANDLE_RIGHT_SHARE    = 1u << 3,
    AI_HANDLE_RIGHT_TRANSFER = 1u << 4,
    AI_HANDLE_RIGHT_ADMIN    = 1u << 5
};

#define AI_HANDLE_RIGHT_ALL ((ai_handle_rights_t)( \
    AI_HANDLE_RIGHT_READ     | \
    AI_HANDLE_RIGHT_WRITE    | \
    AI_HANDLE_RIGHT_MAP      | \
    AI_HANDLE_RIGHT_SHARE    | \
    AI_HANDLE_RIGHT_TRANSFER | \
    AI_HANDLE_RIGHT_ADMIN))

typedef struct {
    void *object;
    u32 generation;
    ai_handle_object_type type;
    ai_handle_rights_t rights;
    bool occupied;
} ai_handle_entry;

typedef struct {
    ai_handle_entry entries[AI_DOMAIN_MAX_HANDLES];
    u32 live_count;
} ai_handle_table;

struct ai_domain;

void ai_handle_table_init(ai_handle_table *table);

ai_handle_t ai_handle_install(
    struct ai_domain *domain,
    void *object,
    ai_handle_object_type type,
    ai_handle_rights_t rights
);

void *ai_handle_resolve(
    const struct ai_domain *domain,
    ai_handle_t handle,
    ai_handle_object_type expected_type,
    ai_handle_rights_t required_rights
);

bool ai_handle_is_valid(
    const struct ai_domain *domain,
    ai_handle_t handle,
    ai_handle_object_type expected_type,
    ai_handle_rights_t required_rights
);

bool ai_handle_has_rights(
    const struct ai_domain *domain,
    ai_handle_t handle,
    ai_handle_rights_t required_rights
);

ai_handle_rights_t ai_handle_get_rights(
    const struct ai_domain *domain,
    ai_handle_t handle
);

/*
 * Permanently reduce the authority carried by an existing handle entry.
 * new_rights must be nonzero and a subset of the current rights.
 * Rights can never be added through this operation.
 */
bool ai_handle_restrict_rights(
    struct ai_domain *domain,
    ai_handle_t handle,
    ai_handle_rights_t new_rights
);


/*
 * Create a rights-attenuated handle in another ACTIVE domain while keeping
 * the source handle valid. The source handle must carry SHARE. requested_rights
 * must be a nonzero subset of the source entry rights. Same-domain delegation
 * is intentionally rejected in this prototype.
 *
 * Returns AI_HANDLE_INVALID on any failure.
 */
ai_handle_t ai_handle_share(
    struct ai_domain *source_domain,
    ai_handle_t source_handle,
    struct ai_domain *target_domain,
    ai_handle_rights_t requested_rights
);

/*
 * Move authority to another ACTIVE domain. The source handle must carry
 * TRANSFER. The destination handle is installed first; only then is the source
 * handle invalidated. If destination installation or source invalidation fails,
 * the operation rolls back and returns AI_HANDLE_INVALID.
 *
 * A successful transfer may attenuate rights: requested_rights only needs to be
 * a nonzero subset of the source rights. Rights omitted during transfer are
 * deliberately discarded.
 */
ai_handle_t ai_handle_transfer(
    struct ai_domain *source_domain,
    ai_handle_t source_handle,
    struct ai_domain *target_domain,
    ai_handle_rights_t requested_rights
);

bool ai_handle_close(struct ai_domain *domain, ai_handle_t handle);

bool ai_handle_rights_valid(ai_handle_rights_t rights);
u32 ai_handle_live_count(const struct ai_domain *domain);
u32 ai_handle_domain_tag(ai_handle_t handle);
u32 ai_handle_generation(ai_handle_t handle);
u32 ai_handle_slot(ai_handle_t handle);
const char *ai_handle_object_type_name(ai_handle_object_type type);

#endif
