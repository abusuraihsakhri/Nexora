# Nexora / AIKernel — Phase 4 Step 6

This tree is the cumulative Nexora kernel prototype through **Phase 4 Step 6:
zero-copy tensor mapping**.

## Phase 4 progress

- Step 2 — work domains: implemented
- Step 3 — generation-protected per-domain handles: implemented
- Step 4 — capability-style handle rights: implemented
- Step 5 — cross-domain SHARE / TRANSFER: implemented
- **Step 6 — shared physical tensor backing + zero-copy mapping: implemented**
- Step 7 — reference counting / lifetime management: next

## Step 6 in one diagram

```text
                    ai_tensor
                        |
                        v
              ai_tensor_backing
              physical pages P0,P1
                   /         \
                  /           \
                 v             v
        Domain A mapping   Domain B mapping
        VA_A -> P0,P1      VA_B -> P0,P1
        READ|WRITE         READ
```

Domain A and Domain B receive separate domain-scoped mapping IDs and separate
logical virtual addresses. Both mappings point to the same backing pages, so
sharing does not duplicate tensor payload bytes.

## New Step 6 components

```text
include/ai/backing.h
src/ai/backing.c

include/ai/mapping.h
src/ai/mapping.c

tests/mapping_host_test.c
docs/PHASE4_STEP6.md
```

`ai_tensor` now has a backing pointer and backing offset, and `ai_domain` now has
an independent mapping table. Domain destruction requires both the handle table
and mapping table to be drained.

## Rights model

Mapping requires:

```text
READ mapping       => READ | MAP handle rights
READ|WRITE mapping => READ | WRITE | MAP handle rights
```

Rights are still stored in the protected handle table and cannot be manufactured
by modifying a numeric token.

## Important current boundary

The Step 6 mapping layer assigns per-domain **logical** virtual addresses and
records their physical translations. Nexora does not yet have separate hardware
page tables for each work domain. The current boot page tables still provide a
single identity-mapped kernel address space.

Therefore Step 6 proves the zero-copy object/memory architecture without falsely
claiming MMU-enforced user-space isolation. Hardware binding comes with the VM
and user-mode substrate.

## Build

Build the kernel ELF without requiring GRUB tooling:

```bash
make build/kernel.elf
```

Run all host tests:

```bash
make test-host
```

Run the Step 6 mapping test with AddressSanitizer and UBSan:

```bash
make test-host-sanitize
```

Creating the bootable ISO still requires GRUB/xorriso tooling.

## Validation

This Step 6 package was compiled with:

```text
-std=c11 -O2 -Wall -Wextra -Werror
```

Kernel build, legacy handle tests, delegation tests, zero-copy mapping tests,
and the sanitizer mapping test all pass. See `VALIDATION.txt`.

## Next

**Phase 4 Step 7 — reference counting and lifetime management** will connect
handle lifetime, tensor lifetime, backing lifetime, and mapping lifetime so that
shared physical pages are reclaimed only after the final legitimate reference
has disappeared.
