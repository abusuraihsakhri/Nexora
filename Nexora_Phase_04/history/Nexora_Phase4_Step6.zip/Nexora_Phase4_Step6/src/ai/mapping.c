#include <ai/mapping.h>
#include <ai/backing.h>
#include <ai/domain.h>
#include <ai/handle.h>
#include <ai/tensor.h>

#define AI_MAPPING_SLOT_MASK        0xffull
#define AI_MAPPING_GENERATION_MASK  0xffffffull
#define AI_MAPPING_DOMAIN_MASK      0xffffffffull
#define AI_MAPPING_GENERATION_SHIFT 8u
#define AI_MAPPING_DOMAIN_SHIFT     32u

_Static_assert(AI_DOMAIN_MAX_MAPPINGS <= 255u,
               "mapping slot encoding supports at most 255 entries");

static u64 align_up_page(u64 value) {
    if (value == 0) {
        return 0;
    }
    return (value + AI_MAPPING_PAGE_SIZE - 1ull) &
           ~(AI_MAPPING_PAGE_SIZE - 1ull);
}

static u32 next_generation(u32 current) {
    u32 next = (current + 1u) & (u32)AI_MAPPING_GENERATION_MASK;
    if (next == 0) {
        next = 1;
    }
    return next;
}

static ai_mapping_id_t encode_mapping(
    u32 domain_tag,
    u32 generation,
    u32 slot_index
) {
    u64 slot_token = (u64)(slot_index + 1u);
    u64 generation_bits =
        ((u64)generation & AI_MAPPING_GENERATION_MASK)
        << AI_MAPPING_GENERATION_SHIFT;
    u64 domain_bits =
        ((u64)domain_tag & AI_MAPPING_DOMAIN_MASK)
        << AI_MAPPING_DOMAIN_SHIFT;

    return domain_bits | generation_bits | slot_token;
}

static bool decode_slot(ai_mapping_id_t mapping, u32 *slot_index) {
    u32 slot_token = (u32)(mapping & AI_MAPPING_SLOT_MASK);
    if (slot_token == 0 || slot_token > AI_DOMAIN_MAX_MAPPINGS) {
        return false;
    }

    if (slot_index) {
        *slot_index = slot_token - 1u;
    }
    return true;
}

static bool mapping_domain_live(const ai_domain *domain) {
    return domain &&
           (domain->state == AI_DOMAIN_ACTIVE ||
            domain->state == AI_DOMAIN_QUIESCING);
}

static bool mapping_protection_valid(ai_mapping_prot_t protection) {
    if ((protection & AI_MAP_PROT_READ) == 0) {
        return false;
    }
    return (protection & ~(AI_MAP_PROT_READ | AI_MAP_PROT_WRITE)) == 0;
}

static const ai_mapping_entry *lookup_entry_const(
    const ai_domain *domain,
    ai_mapping_id_t mapping
) {
    if (!mapping_domain_live(domain) || mapping == AI_MAPPING_INVALID) {
        return NULL;
    }

    if (ai_mapping_domain_tag(mapping) != (u32)domain->id) {
        return NULL;
    }

    u32 slot_index = 0;
    if (!decode_slot(mapping, &slot_index)) {
        return NULL;
    }

    const ai_mapping_entry *entry = &domain->mappings.entries[slot_index];
    if (!entry->occupied || !entry->tensor || !entry->backing) {
        return NULL;
    }

    if (entry->generation != ai_mapping_generation(mapping)) {
        return NULL;
    }

    return entry;
}

static ai_mapping_entry *lookup_entry(
    ai_domain *domain,
    ai_mapping_id_t mapping
) {
    return (ai_mapping_entry *)lookup_entry_const(domain, mapping);
}

void ai_mapping_table_init(ai_mapping_table *table, u64 domain_id) {
    if (!table) {
        return;
    }

    table->live_count = 0;
    table->next_virtual_address =
        AI_MAPPING_VA_BASE +
        ((domain_id - 1ull) * AI_MAPPING_DOMAIN_STRIDE);

    for (u32 i = 0; i < AI_DOMAIN_MAX_MAPPINGS; ++i) {
        ai_mapping_entry *entry = &table->entries[i];
        entry->tensor = NULL;
        entry->backing = NULL;
        entry->tensor_offset = 0;
        entry->length = 0;
        entry->mapped_bytes = 0;
        entry->virtual_base = 0;
        entry->physical_base = 0;
        entry->kernel_base = NULL;
        entry->generation = 1;
        entry->protection = 0;
        entry->occupied = false;
    }
}

ai_mapping_id_t ai_tensor_map(
    ai_domain *domain,
    u64 tensor_handle,
    ai_mapping_prot_t protection
) {
    ai_tensor *tensor = (ai_tensor *)ai_handle_resolve(
        domain,
        (ai_handle_t)tensor_handle,
        AI_HANDLE_OBJECT_TENSOR,
        AI_HANDLE_RIGHT_MAP | AI_HANDLE_RIGHT_READ
    );
    if (!tensor) {
        return AI_MAPPING_INVALID;
    }

    return ai_tensor_map_range(
        domain,
        tensor_handle,
        0,
        tensor->bytes,
        protection
    );
}

ai_mapping_id_t ai_tensor_map_range(
    ai_domain *domain,
    u64 tensor_handle,
    u64 tensor_offset,
    u64 length,
    ai_mapping_prot_t protection
) {
    if (!domain || domain->state != AI_DOMAIN_ACTIVE ||
        !mapping_protection_valid(protection) || length == 0) {
        return AI_MAPPING_INVALID;
    }

    ai_handle_rights_t required =
        AI_HANDLE_RIGHT_MAP | AI_HANDLE_RIGHT_READ;
    if ((protection & AI_MAP_PROT_WRITE) != 0) {
        required |= AI_HANDLE_RIGHT_WRITE;
    }

    ai_tensor *tensor = (ai_tensor *)ai_handle_resolve(
        domain,
        (ai_handle_t)tensor_handle,
        AI_HANDLE_OBJECT_TENSOR,
        required
    );
    if (!tensor || !tensor->backing || !tensor->backing->kernel_base) {
        return AI_MAPPING_INVALID;
    }

    if ((tensor_offset & (AI_MAPPING_PAGE_SIZE - 1ull)) != 0) {
        return AI_MAPPING_INVALID;
    }

    if (tensor_offset > tensor->bytes || length > tensor->bytes - tensor_offset) {
        return AI_MAPPING_INVALID;
    }

    u64 backing_offset = tensor->backing_offset + tensor_offset;
    if (backing_offset > tensor->backing->size_bytes ||
        length > tensor->backing->size_bytes - backing_offset) {
        return AI_MAPPING_INVALID;
    }

    if ((backing_offset & (AI_MAPPING_PAGE_SIZE - 1ull)) != 0) {
        return AI_MAPPING_INVALID;
    }

    u64 mapped_bytes = align_up_page(length);
    if (mapped_bytes == 0) {
        return AI_MAPPING_INVALID;
    }

    u64 window_start = AI_MAPPING_VA_BASE +
        ((domain->id - 1ull) * AI_MAPPING_DOMAIN_STRIDE);
    u64 window_end = window_start + AI_MAPPING_DOMAIN_STRIDE;
    u64 virtual_base = domain->mappings.next_virtual_address;

    if (virtual_base < window_start || virtual_base > window_end ||
        mapped_bytes > window_end - virtual_base) {
        return AI_MAPPING_INVALID;
    }

    u32 slot_index = AI_DOMAIN_MAX_MAPPINGS;
    for (u32 i = 0; i < AI_DOMAIN_MAX_MAPPINGS; ++i) {
        if (!domain->mappings.entries[i].occupied) {
            slot_index = i;
            break;
        }
    }
    if (slot_index == AI_DOMAIN_MAX_MAPPINGS) {
        return AI_MAPPING_INVALID;
    }

    if (!ai_backing_mapping_acquire(tensor->backing)) {
        return AI_MAPPING_INVALID;
    }

    ai_mapping_entry *entry = &domain->mappings.entries[slot_index];
    entry->tensor = tensor;
    entry->backing = tensor->backing;
    entry->tensor_offset = tensor_offset;
    entry->length = length;
    entry->mapped_bytes = mapped_bytes;
    entry->virtual_base = virtual_base;
    entry->physical_base = ai_backing_physical_at(
        tensor->backing,
        backing_offset
    );
    entry->kernel_base = ai_backing_kernel_at(
        tensor->backing,
        backing_offset
    );
    entry->protection = protection;
    entry->occupied = true;

    domain->mappings.live_count++;

    u64 next = virtual_base + mapped_bytes;
    if (AI_MAPPING_GUARD_BYTES <= window_end - next) {
        next += AI_MAPPING_GUARD_BYTES;
    }
    domain->mappings.next_virtual_address = next;

    return encode_mapping(
        (u32)domain->id,
        entry->generation,
        slot_index
    );
}

const ai_mapping_entry *ai_mapping_resolve(
    const ai_domain *domain,
    ai_mapping_id_t mapping
) {
    return lookup_entry_const(domain, mapping);
}

bool ai_tensor_unmap(ai_domain *domain, ai_mapping_id_t mapping) {
    ai_mapping_entry *entry = lookup_entry(domain, mapping);
    if (!entry || domain->mappings.live_count == 0) {
        return false;
    }

    ai_backing_mapping_release(entry->backing);

    entry->tensor = NULL;
    entry->backing = NULL;
    entry->tensor_offset = 0;
    entry->length = 0;
    entry->mapped_bytes = 0;
    entry->virtual_base = 0;
    entry->physical_base = 0;
    entry->kernel_base = NULL;
    entry->protection = 0;
    entry->occupied = false;
    entry->generation = next_generation(entry->generation);
    domain->mappings.live_count--;

    return true;
}

u32 ai_mapping_live_count(const ai_domain *domain) {
    if (!domain) {
        return 0;
    }
    return domain->mappings.live_count;
}

u32 ai_mapping_domain_tag(ai_mapping_id_t mapping) {
    return (u32)((mapping >> AI_MAPPING_DOMAIN_SHIFT) & AI_MAPPING_DOMAIN_MASK);
}

u32 ai_mapping_generation(ai_mapping_id_t mapping) {
    return (u32)(
        (mapping >> AI_MAPPING_GENERATION_SHIFT) &
        AI_MAPPING_GENERATION_MASK
    );
}

u32 ai_mapping_slot(ai_mapping_id_t mapping) {
    u32 slot_index = 0;
    if (!decode_slot(mapping, &slot_index)) {
        return AI_DOMAIN_MAX_MAPPINGS;
    }
    return slot_index;
}

u64 ai_mapping_virtual_address(
    const ai_domain *domain,
    ai_mapping_id_t mapping
) {
    const ai_mapping_entry *entry = lookup_entry_const(domain, mapping);
    return entry ? entry->virtual_base : 0;
}

u64 ai_mapping_physical_address(
    const ai_domain *domain,
    ai_mapping_id_t mapping
) {
    const ai_mapping_entry *entry = lookup_entry_const(domain, mapping);
    return entry ? entry->physical_base : 0;
}

void *ai_mapping_kernel_address(
    const ai_domain *domain,
    ai_mapping_id_t mapping
) {
    const ai_mapping_entry *entry = lookup_entry_const(domain, mapping);
    return entry ? entry->kernel_base : NULL;
}

bool ai_mapping_translate(
    const ai_domain *domain,
    ai_mapping_id_t mapping,
    u64 virtual_address,
    u64 *physical_address
) {
    const ai_mapping_entry *entry = lookup_entry_const(domain, mapping);
    if (!entry || !physical_address) {
        return false;
    }

    if (virtual_address < entry->virtual_base) {
        return false;
    }

    u64 offset = virtual_address - entry->virtual_base;
    if (offset >= entry->length) {
        return false;
    }

    *physical_address = entry->physical_base + offset;
    return true;
}
