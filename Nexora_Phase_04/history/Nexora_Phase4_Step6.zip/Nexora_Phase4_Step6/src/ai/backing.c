#include <ai/backing.h>
#include <kernel/memory.h>
#include <kernel/panic.h>

static ai_tensor_backing *registry[AI_MAX_BACKINGS];
static u64 backing_count = 0;
static u64 next_backing_id = 1;

static u64 align_up_page(u64 value) {
    if (value == 0) {
        return 0;
    }
    return (value + AI_BACKING_PAGE_SIZE - 1ull) &
           ~(AI_BACKING_PAGE_SIZE - 1ull);
}

void ai_backing_system_init(void) {
    for (u32 i = 0; i < AI_MAX_BACKINGS; ++i) {
        registry[i] = NULL;
    }
    backing_count = 0;
    next_backing_id = 1;
}

ai_tensor_backing *ai_backing_create_ram(u64 size_bytes, u32 flags) {
    if (size_bytes == 0 || backing_count >= AI_MAX_BACKINGS) {
        return NULL;
    }

    u64 allocation_bytes = align_up_page(size_bytes);
    if (allocation_bytes < size_bytes) {
        return NULL;
    }

    ai_tensor_backing *backing =
        (ai_tensor_backing *)kalloc(sizeof(ai_tensor_backing), 16);
    void *storage = kalloc((usize)allocation_bytes, (usize)AI_BACKING_PAGE_SIZE);

    backing->id = next_backing_id++;
    backing->kind = AI_BACKING_RAM;
    backing->size_bytes = size_bytes;
    backing->allocation_bytes = allocation_bytes;
    backing->page_count = allocation_bytes / AI_BACKING_PAGE_SIZE;
    backing->kernel_base = storage;
    backing->physical_base = (u64)(usize)storage;
    backing->mapping_count = 0;
    backing->flags = flags;

    if ((flags & AI_BACKING_ZEROED) != 0) {
        u8 *bytes = (u8 *)storage;
        for (u64 i = 0; i < allocation_bytes; ++i) {
            bytes[i] = 0;
        }
    }

    registry[backing_count++] = backing;
    return backing;
}

bool ai_backing_mapping_acquire(ai_tensor_backing *backing) {
    if (!backing) {
        return false;
    }
    if (backing->mapping_count == ~0ull) {
        return false;
    }
    backing->mapping_count++;
    return true;
}

void ai_backing_mapping_release(ai_tensor_backing *backing) {
    if (!backing) {
        return;
    }
    if (backing->mapping_count == 0) {
        panic("tensor backing mapping-count underflow");
    }
    backing->mapping_count--;
}

u64 ai_backing_count(void) {
    return backing_count;
}

u64 ai_backing_physical_at(const ai_tensor_backing *backing, u64 offset) {
    if (!backing || offset >= backing->allocation_bytes) {
        return 0;
    }
    return backing->physical_base + offset;
}

void *ai_backing_kernel_at(const ai_tensor_backing *backing, u64 offset) {
    if (!backing || !backing->kernel_base || offset >= backing->allocation_bytes) {
        return NULL;
    }
    return (void *)((u8 *)backing->kernel_base + offset);
}

const char *ai_backing_kind_name(ai_backing_kind kind) {
    switch (kind) {
        case AI_BACKING_RAM:    return "RAM";
        case AI_BACKING_DEVICE: return "DEVICE";
        case AI_BACKING_PINNED: return "PINNED";
        case AI_BACKING_REMOTE: return "REMOTE";
        default:                return "UNKNOWN";
    }
}
