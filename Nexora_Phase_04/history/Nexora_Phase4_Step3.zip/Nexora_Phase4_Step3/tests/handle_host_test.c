#include <assert.h>

#include <ai/domain.h>
#include <ai/handle.h>
#include <kernel/memory.h>
#include <kernel/panic.h>

#define TEST_ARENA_SIZE (256u * 1024u)

static u8 test_arena[TEST_ARENA_SIZE];
static usize test_offset = 0;

void early_heap_init(void) {
    test_offset = 0;
}

void *kalloc(usize size, usize alignment) {
    if (alignment == 0) {
        alignment = 1;
    }

    usize aligned = (test_offset + alignment - 1) & ~(alignment - 1);
    if (aligned + size > TEST_ARENA_SIZE) {
        __builtin_trap();
    }

    void *ptr = &test_arena[aligned];
    test_offset = aligned + size;
    return ptr;
}

usize early_heap_used(void) { return test_offset; }
usize early_heap_capacity(void) { return TEST_ARENA_SIZE; }

__attribute__((noreturn))
void panic(const char *message) {
    (void)message;
    __builtin_trap();
}

int main(void) {
    early_heap_init();
    ai_domain_system_init();

    ai_domain_limits unlimited = {0, 0, 0};
    ai_domain *a = ai_domain_create("a", 0, unlimited);
    ai_domain *b = ai_domain_create("b", 0, unlimited);
    assert(a && b);
    assert(ai_domain_activate(a));
    assert(ai_domain_activate(b));

    u64 object = 42;
    ai_handle_t h1 = ai_handle_install(a, &object, AI_HANDLE_OBJECT_TENSOR);
    assert(h1 != AI_HANDLE_INVALID);
    assert(ai_handle_domain_tag(h1) == (u32)a->id);
    assert(ai_handle_resolve(a, h1, AI_HANDLE_OBJECT_TENSOR) == &object);
    assert(ai_handle_resolve(b, h1, AI_HANDLE_OBJECT_TENSOR) == NULL);
    assert(ai_handle_resolve(a, h1, AI_HANDLE_OBJECT_WORK) == NULL);

    assert(ai_handle_close(a, h1));
    assert(ai_handle_resolve(a, h1, AI_HANDLE_OBJECT_TENSOR) == NULL);
    assert(!ai_handle_close(a, h1));

    ai_handle_t h2 = ai_handle_install(a, &object, AI_HANDLE_OBJECT_TENSOR);
    assert(h2 != AI_HANDLE_INVALID);
    assert(h2 != h1);
    assert(ai_handle_slot(h2) == ai_handle_slot(h1));
    assert(ai_handle_generation(h2) != ai_handle_generation(h1));

    assert(ai_domain_begin_quiesce(a));
    assert(ai_handle_install(a, &object, AI_HANDLE_OBJECT_TENSOR) ==
           AI_HANDLE_INVALID);
    assert(!ai_domain_destroy(a));
    assert(ai_handle_close(a, h2));
    assert(ai_domain_destroy(a));

    u64 objects[AI_DOMAIN_MAX_HANDLES + 1u];
    ai_handle_t handles[AI_DOMAIN_MAX_HANDLES];
    for (u32 i = 0; i < AI_DOMAIN_MAX_HANDLES; ++i) {
        objects[i] = i;
        handles[i] = ai_handle_install(
            b,
            &objects[i],
            AI_HANDLE_OBJECT_GENERIC
        );
        assert(handles[i] != AI_HANDLE_INVALID);
    }

    objects[AI_DOMAIN_MAX_HANDLES] = 999;
    assert(ai_handle_install(
               b,
               &objects[AI_DOMAIN_MAX_HANDLES],
               AI_HANDLE_OBJECT_GENERIC) == AI_HANDLE_INVALID);
    assert(ai_handle_live_count(b) == AI_DOMAIN_MAX_HANDLES);

    for (u32 i = 0; i < AI_DOMAIN_MAX_HANDLES; ++i) {
        assert(ai_handle_close(b, handles[i]));
    }
    assert(ai_handle_live_count(b) == 0);
    assert(ai_domain_begin_quiesce(b));
    assert(ai_domain_destroy(b));
    assert(ai_domain_count() == 0);

    return 0;
}
