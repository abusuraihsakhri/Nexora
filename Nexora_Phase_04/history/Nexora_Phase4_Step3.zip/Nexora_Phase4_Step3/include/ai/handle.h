#ifndef AIKERNEL_AI_HANDLE_H
#define AIKERNEL_AI_HANDLE_H

#include <kernel/types.h>

/*
 * Phase 4 Step 3: per-domain opaque object handles.
 *
 * Handles are intentionally not kernel pointers. The current prototype packs:
 *
 *   63                              32 31             8 7        0
 *  +----------------------------------+----------------+----------+
 *  |          domain tag (32)         | generation(24) | slot(8)  |
 *  +----------------------------------+----------------+----------+
 *
 * The slot field stores index + 1, so handle value 0 remains permanently
 * invalid. AI_DOMAIN_MAX_HANDLES is kept <= 255 for this encoding.
 */

typedef u64 ai_handle_t;

#define AI_HANDLE_INVALID ((ai_handle_t)0)
#define AI_DOMAIN_MAX_HANDLES 64u

typedef enum {
    AI_HANDLE_OBJECT_NONE = 0,
    AI_HANDLE_OBJECT_TENSOR,
    AI_HANDLE_OBJECT_BACKING,
    AI_HANDLE_OBJECT_WORK,
    AI_HANDLE_OBJECT_GENERIC,
    AI_HANDLE_OBJECT_ANY = 0xff
} ai_handle_object_type;

typedef struct {
    void *object;
    u32 generation;
    ai_handle_object_type type;
    bool occupied;
} ai_handle_entry;

typedef struct {
    ai_handle_entry entries[AI_DOMAIN_MAX_HANDLES];
    u32 live_count;
} ai_handle_table;

struct ai_domain;

void ai_handle_table_init(ai_handle_table *table);

ai_handle_t ai_handle_install(
    struct ai_domain *domain,
    void *object,
    ai_handle_object_type type
);

void *ai_handle_resolve(
    const struct ai_domain *domain,
    ai_handle_t handle,
    ai_handle_object_type expected_type
);

bool ai_handle_is_valid(
    const struct ai_domain *domain,
    ai_handle_t handle,
    ai_handle_object_type expected_type
);

bool ai_handle_close(struct ai_domain *domain, ai_handle_t handle);

u32 ai_handle_live_count(const struct ai_domain *domain);
u32 ai_handle_domain_tag(ai_handle_t handle);
u32 ai_handle_generation(ai_handle_t handle);
u32 ai_handle_slot(ai_handle_t handle);
const char *ai_handle_object_type_name(ai_handle_object_type type);

#endif
