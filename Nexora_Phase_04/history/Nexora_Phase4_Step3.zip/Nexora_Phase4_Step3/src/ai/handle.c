#include <ai/handle.h>
#include <ai/domain.h>

#define AI_HANDLE_SLOT_MASK       0xffull
#define AI_HANDLE_GENERATION_MASK 0xffffffull
#define AI_HANDLE_DOMAIN_MASK     0xffffffffull
#define AI_HANDLE_GENERATION_SHIFT 8u
#define AI_HANDLE_DOMAIN_SHIFT     32u

_Static_assert(AI_DOMAIN_MAX_HANDLES <= 255u,
               "handle slot encoding supports at most 255 entries");

static u32 next_generation(u32 current) {
    u32 next = (current + 1u) & (u32)AI_HANDLE_GENERATION_MASK;
    if (next == 0) {
        next = 1;
    }
    return next;
}

static ai_handle_t encode_handle(
    u32 domain_tag,
    u32 generation,
    u32 slot_index
) {
    u64 slot_token = (u64)(slot_index + 1u);
    u64 generation_bits =
        ((u64)generation & AI_HANDLE_GENERATION_MASK)
        << AI_HANDLE_GENERATION_SHIFT;
    u64 domain_bits =
        ((u64)domain_tag & AI_HANDLE_DOMAIN_MASK)
        << AI_HANDLE_DOMAIN_SHIFT;

    return domain_bits | generation_bits | slot_token;
}

static bool decode_slot(ai_handle_t handle, u32 *slot_index) {
    u32 slot_token = (u32)(handle & AI_HANDLE_SLOT_MASK);
    if (slot_token == 0 || slot_token > AI_DOMAIN_MAX_HANDLES) {
        return false;
    }

    if (slot_index) {
        *slot_index = slot_token - 1u;
    }
    return true;
}

static bool domain_accepts_existing_handles(const ai_domain *domain) {
    if (!domain) {
        return false;
    }
    return domain->state == AI_DOMAIN_ACTIVE ||
           domain->state == AI_DOMAIN_QUIESCING;
}

void ai_handle_table_init(ai_handle_table *table) {
    if (!table) {
        return;
    }

    table->live_count = 0;
    for (u32 i = 0; i < AI_DOMAIN_MAX_HANDLES; ++i) {
        table->entries[i].object = NULL;
        table->entries[i].generation = 1;
        table->entries[i].type = AI_HANDLE_OBJECT_NONE;
        table->entries[i].occupied = false;
    }
}

ai_handle_t ai_handle_install(
    ai_domain *domain,
    void *object,
    ai_handle_object_type type
) {
    if (!domain || !object || domain->state != AI_DOMAIN_ACTIVE) {
        return AI_HANDLE_INVALID;
    }

    if (type == AI_HANDLE_OBJECT_NONE || type == AI_HANDLE_OBJECT_ANY) {
        return AI_HANDLE_INVALID;
    }

    if (domain->id == 0 || domain->id > AI_DOMAIN_ID_MAX) {
        return AI_HANDLE_INVALID;
    }

    for (u32 i = 0; i < AI_DOMAIN_MAX_HANDLES; ++i) {
        ai_handle_entry *entry = &domain->handles.entries[i];
        if (entry->occupied) {
            continue;
        }

        entry->object = object;
        entry->type = type;
        entry->occupied = true;
        domain->handles.live_count++;

        return encode_handle(
            (u32)domain->id,
            entry->generation,
            i
        );
    }

    return AI_HANDLE_INVALID;
}

void *ai_handle_resolve(
    const ai_domain *domain,
    ai_handle_t handle,
    ai_handle_object_type expected_type
) {
    if (!domain_accepts_existing_handles(domain) ||
        handle == AI_HANDLE_INVALID) {
        return NULL;
    }

    /* A handle copied from another domain must fail before table lookup. */
    if (ai_handle_domain_tag(handle) != (u32)domain->id) {
        return NULL;
    }

    u32 slot_index = 0;
    if (!decode_slot(handle, &slot_index)) {
        return NULL;
    }

    const ai_handle_entry *entry = &domain->handles.entries[slot_index];
    if (!entry->occupied || !entry->object) {
        return NULL;
    }

    if (entry->generation != ai_handle_generation(handle)) {
        return NULL;
    }

    if (expected_type != AI_HANDLE_OBJECT_ANY &&
        entry->type != expected_type) {
        return NULL;
    }

    return entry->object;
}

bool ai_handle_is_valid(
    const ai_domain *domain,
    ai_handle_t handle,
    ai_handle_object_type expected_type
) {
    return ai_handle_resolve(domain, handle, expected_type) != NULL;
}

bool ai_handle_close(ai_domain *domain, ai_handle_t handle) {
    if (!domain_accepts_existing_handles(domain) ||
        handle == AI_HANDLE_INVALID) {
        return false;
    }

    if (ai_handle_domain_tag(handle) != (u32)domain->id) {
        return false;
    }

    u32 slot_index = 0;
    if (!decode_slot(handle, &slot_index)) {
        return false;
    }

    ai_handle_entry *entry = &domain->handles.entries[slot_index];
    if (!entry->occupied ||
        entry->generation != ai_handle_generation(handle) ||
        domain->handles.live_count == 0) {
        return false;
    }

    entry->object = NULL;
    entry->type = AI_HANDLE_OBJECT_NONE;
    entry->occupied = false;
    entry->generation = next_generation(entry->generation);
    domain->handles.live_count--;
    return true;
}

u32 ai_handle_live_count(const ai_domain *domain) {
    if (!domain) {
        return 0;
    }
    return domain->handles.live_count;
}

u32 ai_handle_domain_tag(ai_handle_t handle) {
    return (u32)((handle >> AI_HANDLE_DOMAIN_SHIFT) & AI_HANDLE_DOMAIN_MASK);
}

u32 ai_handle_generation(ai_handle_t handle) {
    return (u32)(
        (handle >> AI_HANDLE_GENERATION_SHIFT) &
        AI_HANDLE_GENERATION_MASK
    );
}

u32 ai_handle_slot(ai_handle_t handle) {
    u32 slot_index = 0;
    if (!decode_slot(handle, &slot_index)) {
        return 0xffffffffu;
    }
    return slot_index;
}

const char *ai_handle_object_type_name(ai_handle_object_type type) {
    switch (type) {
        case AI_HANDLE_OBJECT_NONE:    return "NONE";
        case AI_HANDLE_OBJECT_TENSOR:  return "TENSOR";
        case AI_HANDLE_OBJECT_BACKING: return "BACKING";
        case AI_HANDLE_OBJECT_WORK:    return "WORK";
        case AI_HANDLE_OBJECT_GENERIC: return "GENERIC";
        case AI_HANDLE_OBJECT_ANY:     return "ANY";
        default:                       return "UNKNOWN";
    }
}
