#include <kernel/printk.h>
#include <kernel/memory.h>
#include <kernel/panic.h>
#include <ai/tensor.h>
#include <ai/domain.h>
#include <ai/handle.h>
#include <ai/work.h>
#include <ai/scheduler.h>
#include <ai/capability.h>

static void print_tensor(const ai_tensor *t) {
    kputs("tensor ");
    kputs(t->name);
    kputs(" id=");
    kprint_u64(t->id);
    kputs(" dtype=");
    kputs(ai_dtype_name(t->dtype));
    kputs(" bytes=");
    kprint_u64(t->bytes);
    kputs(" location=");
    kputs(ai_location_name(t->location));
    kputs("\n");
}

static void print_work(const ai_work_node *node) {
    kputs("work node ");
    kprint_u64(node->id);
    kputs(" ");
    kputs(node->name);
    kputs(" op=");
    kputs(ai_op_name(node->op));
    kputs(" state=");
    kputs(ai_work_state_name(node->state));
    kputs(" priority=");
    kprint_u64(node->priority);
    kputs("\n");
}

static void print_domain(const ai_domain *domain) {
    kputs("domain ");
    kprint_u64(domain->id);
    kputs(" ");
    kputs(domain->name);
    kputs(" state=");
    kputs(ai_domain_state_name(domain->state));
    kputs(" memory=");
    kprint_u64(domain->memory_used_bytes);
    kputs(" tensors=");
    kprint_u64(domain->tensor_count);
    kputs(" work=");
    kprint_u64(domain->work_node_count);
    kputs("\n");
}


static void require_demo(bool condition, const char *message) {
    kputs(message);
    kputs(condition ? ": PASS\n" : ": FAIL\n");
    if (!condition) {
        panic("Phase 4 Step 3 handle self-test failed");
    }
}

static void run_handle_demo(void) {
    ai_domain_limits unlimited = {
        .memory_bytes = 0,
        .max_tensors = 0,
        .max_work_nodes = 0
    };

    ai_domain *owner = ai_domain_create("handle-owner", 0, unlimited);
    ai_domain *foreign = ai_domain_create("foreign-domain", 0, unlimited);
    ai_domain_activate(owner);
    ai_domain_activate(foreign);

    u64 shape[1] = {16};
    ai_tensor *tensor = ai_tensor_create(
        "handle-demo-tensor",
        AI_DTYPE_F32,
        1,
        shape,
        AI_LOC_CPU_RAM,
        AI_TENSOR_EPHEMERAL
    );

    kputs("\n[opaque handle demo]\n");

    ai_handle_t first = ai_handle_install(
        owner,
        tensor,
        AI_HANDLE_OBJECT_TENSOR
    );

    kputs("owner handle: ");
    kprint_hex(first);
    kputs(" domain=");
    kprint_u64(ai_handle_domain_tag(first));
    kputs(" generation=");
    kprint_u64(ai_handle_generation(first));
    kputs(" slot=");
    kprint_u64(ai_handle_slot(first));
    kputs("\n");

    require_demo(first != AI_HANDLE_INVALID,
                 "install tensor handle");
    require_demo(
        ai_handle_resolve(owner, first, AI_HANDLE_OBJECT_TENSOR) == tensor,
        "owner resolves its tensor"
    );
    require_demo(
        ai_handle_resolve(foreign, first, AI_HANDLE_OBJECT_TENSOR) == NULL,
        "foreign domain is rejected"
    );
    require_demo(
        ai_handle_resolve(owner, first, AI_HANDLE_OBJECT_WORK) == NULL,
        "object type mismatch is rejected"
    );
    require_demo(ai_handle_close(owner, first),
                 "close first handle");
    require_demo(
        ai_handle_resolve(owner, first, AI_HANDLE_OBJECT_TENSOR) == NULL,
        "closed handle becomes stale"
    );

    ai_handle_t second = ai_handle_install(
        owner,
        tensor,
        AI_HANDLE_OBJECT_TENSOR
    );

    kputs("reissued handle: ");
    kprint_hex(second);
    kputs(" generation=");
    kprint_u64(ai_handle_generation(second));
    kputs("\n");

    require_demo(second != AI_HANDLE_INVALID && second != first,
                 "reused slot gets new generation");
    require_demo(
        ai_handle_resolve(owner, first, AI_HANDLE_OBJECT_TENSOR) == NULL,
        "old generation stays invalid"
    );
    require_demo(
        ai_handle_resolve(owner, second, AI_HANDLE_OBJECT_TENSOR) == tensor,
        "new generation resolves"
    );
    require_demo(ai_handle_live_count(owner) == 1,
                 "live handle accounting");

    require_demo(ai_domain_begin_quiesce(owner),
                 "owner enters quiescing state");
    require_demo(
        !ai_domain_destroy(owner),
        "quiescing domain with live handle cannot be destroyed"
    );
    require_demo(ai_handle_close(owner, second),
                 "close reissued handle while quiescing");
    require_demo(ai_handle_live_count(owner) == 0,
                 "handle table drains to zero");

    ai_domain_begin_quiesce(foreign);
    require_demo(ai_domain_destroy(owner),
                 "owner destroys after handle drain");
    require_demo(ai_domain_destroy(foreign),
                 "foreign domain destroys cleanly");
}

static void run_domain_demo(void) {
    ai_domain_limits producer_limits = {
        .memory_bytes = 1024 * 1024,
        .max_tensors = 4,
        .max_work_nodes = 8
    };

    ai_domain_limits consumer_limits = {
        .memory_bytes = 512 * 1024,
        .max_tensors = 2,
        .max_work_nodes = 4
    };

    ai_domain *producer = ai_domain_create(
        "producer",
        AI_DOMAIN_TRUSTED,
        producer_limits
    );

    ai_domain *consumer = ai_domain_create(
        "consumer",
        0,
        consumer_limits
    );

    ai_domain_activate(producer);
    ai_domain_activate(consumer);

    kputs("\n[work-domain demo]\n");
    print_domain(producer);
    print_domain(consumer);

    kputs("producer charge 256 KiB: ");
    kputs(ai_domain_charge_memory(producer, 256 * 1024) ? "ok\n" : "rejected\n");

    kputs("consumer charge 768 KiB: ");
    kputs(ai_domain_charge_memory(consumer, 768 * 1024) ? "ok\n" : "rejected\n");

    kputs("producer tensor reservation: ");
    kputs(ai_domain_reserve_tensor(producer) ? "ok\n" : "rejected\n");

    print_domain(producer);

    ai_domain_release_tensor(producer);
    ai_domain_uncharge_memory(producer, 256 * 1024);
    ai_domain_begin_quiesce(producer);

    kputs("producer destroy: ");
    kputs(ai_domain_destroy(producer) ? "ok\n" : "rejected\n");

    kputs("live domains: ");
    kprint_u64(ai_domain_count());
    kputs("\n");
}

static void run_demo(void) {
    kputs("\n[AIKernel demo]\n");

    u64 input_shape[2]   = {1, 4096};
    u64 weight_shape[2]  = {4096, 4096};
    u64 hidden_shape[2]  = {1, 4096};

    ai_tensor *input = ai_tensor_create(
        "input",
        AI_DTYPE_F16,
        2,
        input_shape,
        AI_LOC_CPU_RAM,
        AI_TENSOR_EPHEMERAL
    );

    ai_tensor *weights = ai_tensor_create(
        "weights",
        AI_DTYPE_F16,
        2,
        weight_shape,
        AI_LOC_GPU_HBM,
        AI_TENSOR_PERSISTENT | AI_TENSOR_READONLY
    );

    ai_tensor *hidden = ai_tensor_create(
        "hidden",
        AI_DTYPE_F16,
        2,
        hidden_shape,
        AI_LOC_GPU_HBM,
        AI_TENSOR_EPHEMERAL
    );

    ai_tensor *output = ai_tensor_create(
        "output",
        AI_DTYPE_F16,
        2,
        hidden_shape,
        AI_LOC_GPU_HBM,
        AI_TENSOR_EPHEMERAL
    );

    print_tensor(input);
    print_tensor(weights);
    print_tensor(hidden);
    print_tensor(output);

    ai_work_graph graph;
    ai_work_graph_init(&graph);

    ai_work_node *matmul = ai_work_add(
        &graph,
        "projection",
        AI_OP_MATMUL,
        100,
        1000000,
        AI_DEVICE_GPU
    );
    ai_work_add_input(matmul, input);
    ai_work_add_input(matmul, weights);
    ai_work_add_output(matmul, hidden);

    ai_work_node *activation = ai_work_add(
        &graph,
        "activation",
        AI_OP_ACTIVATION,
        90,
        2000000,
        AI_DEVICE_GPU
    );
    ai_work_add_dependency(activation, matmul->id);
    ai_work_add_input(activation, hidden);
    ai_work_add_output(activation, output);

    ai_scheduler scheduler;
    ai_scheduler_init(&scheduler, &graph);

    print_work(matmul);
    print_work(activation);

    ai_work_node *selected = ai_scheduler_pick(&scheduler);
    kputs("scheduler selected node ");
    kprint_u64(selected ? selected->id : 0);
    kputs("\n");

    ai_scheduler_mark_running(&scheduler, selected);
    ai_scheduler_mark_done(&scheduler, selected);

    selected = ai_scheduler_pick(&scheduler);
    kputs("scheduler selected node ");
    kprint_u64(selected ? selected->id : 0);
    kputs("\n");

    ai_scheduler_mark_running(&scheduler, selected);
    ai_scheduler_mark_done(&scheduler, selected);

    ai_capability agent_cap = ai_cap_create(
        42,
        AI_CAP_TENSOR_READ | AI_CAP_MODEL_USE | AI_CAP_GPU_USE
    );

    kputs("agent 42 GPU capability: ");
    kputs(ai_cap_has(&agent_cap, AI_CAP_GPU_USE) ? "yes\n" : "no\n");

    kputs("early heap used: ");
    kprint_u64(early_heap_used());
    kputs(" / ");
    kprint_u64(early_heap_capacity());
    kputs(" bytes\n");
}

void kmain(void) {
    console_init();

    kputs("AIKernel x86_64 booted.\n");

    early_heap_init();
    kputs("Early heap initialized.\n");

    ai_tensor_system_init();
    ai_domain_system_init();
    kputs("AI runtime metadata initialized.\n");

    run_domain_demo();
    run_handle_demo();
    run_demo();

    kputs("\nAIKernel initialization complete.\n");
    kputs("Halting CPU.\n");

    for (;;) {
        __asm__ volatile ("hlt");
    }
}
